/*
 * Copyright (C) 2013 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.indroid;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;

/**
 * This Class provides access to hidden methods and variables of Android Graphics APIs.
 * It also defines utility methods for various Image/Graphics operations.
 * 
 * @author Prasanta Paul
 */
public class GraphicsInternal { 

	/**
	 * Convert normal PNG stored in File System to NinePatch using existing
	 * NinePatch Image's property.</p>
	 * Android appends <code>"nptc"</code>, a private PNG chunk to store Nine Patch properties
	 * inside a PNG image during Compilation (APK generation) and removed 1-Pixel
	 * black border (0xff000000).<br/> 
	 * On runtime, this <code>"nptc"</code> chunk is referred by Android Graphics
	 * framework to stretch/fill Nine Patch image.
	 * <p>
	 * Any normal PNG image (without black border) can be converted to Nine Patch if we insert 
	 * relevant <code>"nptc"</code> chunk on run time. 
	 * 
	 * @param imagFile Image File path in File System. This image shouldn't have Black border.
	 * @param existingNinePatch Existing NinePatch image
	 * @param context
	 * @return Returns Nine Patch Drawable
	 */
	public static NinePatchDrawable createNinePatchDrawable(String imagFile, Bitmap existingNinePatch, Context context) throws IOException {
		FileInputStream input = new FileInputStream(new File(imagFile));
		return createNinePatchDrawable(input, existingNinePatch, context);
	}
	
	/**
	 * Convert an ordinary PNG to Nine Patch using existing Nine Patch image
	 * properties.</br>
	 * You don't have to add Black borders to the image to convert it NinePatch
	 * 
	 * @param input
	 * @param existingNinePatch
	 * @return Returns Nine Patch Drawable
	 */
	public static NinePatchDrawable createNinePatchDrawable(InputStream input, Bitmap existingNinePatch, Context context) {
		Bitmap bitmap = BitmapFactory.decodeStream(input);
		byte[] nptcChunk = existingNinePatch.getNinePatchChunk();
		
		if(nptcChunk == null) {
			System.out.println("Invalid NinePatch image, no NPTC Chunk found");
			return null;
		}
		
		return new NinePatchDrawable(context.getResources(), bitmap, nptcChunk, new Rect(), null);
	}
	
	/**
	 * Get {@link android.graphics.Bitmap} from a {@link android.graphics.drawable.Drawable}
	 * 
	 * @param drawable
	 * @return Returns a {@link android.graphics.Bitmap} generated from 
	 *         {@link android.graphics.drawable.Drawable}
	 */
	public static Bitmap getBitmap(Drawable drawable) {
		if(drawable == null)
			return null;
		
		if(drawable instanceof BitmapDrawable)
			return ((BitmapDrawable) drawable).getBitmap();
		
		Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		
		drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		drawable.draw(canvas);
		
		return bitmap;
	}
}
