/*
 * Copyright (C) 2013 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.indroid;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

/**
 * This Class provides access to hidden methods and variables of {@link android.app.Activity}, 
 * {@link android.app.WallpaperManager} and {@link android.view.View} components.
 * 
 * @author Prasanta Paul
 * @see GraphicsInternal 
 * @see TelephonyInternal
 */
public class Internal {
	
	/**
	 * Get instance of Menu associated with an Activity/Window. This method is
	 * required if transformMenu() is called from other than 
	 * {@link Activity#onPrepareOptionsMenu(Menu)} or {@link Activity#onCreateOptionsMenu(Menu)}
	 * <p>
	 * - There is no public API to access menu instance</br>
	 * - <code>Activity</code> -> <code>PhoneWindow</code> (extends {@link Window})</br>
	 * - <code>PhoneWindow</code> has an inner Class <code>PanelFeatureState</code> which holds instance
	 * of present <code>MenuBuilder</code>.</br>
	 * - <code>MenuBuilder</code> is implementation class for {@link Menu}</br>
	 * - There is a variable <code>mPreparedPanel</code> in PanelFeatureState which contains 
	 * present {@link Menu} instance</br>
	 * <p>
	 * Call {@link Activity#invalidateOptionsMenu()} prior to execute below steps-</br>
	 * 1. Get <code>Window</code> instance, {@link Activity#getWindow()} returns instance of PhoneWindow</br>
	 * 2. Get value of <code>mPreparedPanel</code> (instance of <code>PanelFeatureState</code>) 
	 *    from <code>PhoneWindow</code></br>
	 * 3. Get instance of <code>MenuBuilder</code> ("menu") from <code>PanelFeatureState</code></br>
	 * 4. Now you have the instance of {@link Menu}.</br>
	 * 
	 * @return Returns {@link Menu} instance
	 */
	public static Menu menuInstance(Activity activity) {
		/*
		 * Read Menu builder instance from PhoneWindow.java
		 * PhoneWindow -> getPanelState() -> PanelFeatureState -> menu (MenuBuilder instance)
		 */
		if(activity == null)
			return null;
		Menu menu = null;
		Window phone = activity.getWindow();
		Class phoneCl = activity.getWindow().getClass();
		
		try {
			// Get the recent instance of PanelFeatureState
			Field panelField = phoneCl.getDeclaredField("mPreparedPanel");
			panelField.setAccessible(true);
			Object panelFeatureState = panelField.get(activity.getWindow());
			
			// Get menu instance
			Field menuField = panelFeatureState.getClass().getDeclaredField("menu");
			menuField.setAccessible(true);
			menu = (Menu) menuField.get(panelFeatureState);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return menu;
	}
	
	/**
	 * Set Color of ActionBar Title
	 * 
	 * @param actionBar
	 * @param titleColor
	 */
	public static void setActionBarTitleColor(android.app.ActionBar actionBar, int titleColor) {
		if(actionBar == null)
			return;
		// Java Reflection
		// Read TextView used by ActionBar to display Title
		try {
			Field actionViewField = actionBar.getClass().getDeclaredField("mActionView");
			actionViewField.setAccessible(true);
			Object actionView = actionViewField.get(actionBar);
			if(actionView == null)
				return;
			
			Field titleTextField = actionView.getClass().getDeclaredField("mTitleView");
			titleTextField.setAccessible(true);
			TextView titleText = (TextView)titleTextField.get(actionView);
			
			if(titleText != null)
				titleText.setTextColor(titleColor);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Set Wallpaper as background of {@link android.app.Activity} or {@link android.app.Fragment}. It 
	 * returns Hash of the Wallpaper Image. This hash value can be used to check 
	 * whether Wallpaper has been changed or not.
	 * <p> 
	 * If it fails to extract Bitmap from Wallpaper Manager, it will return 0.
	 * 
	 * @param activity
	 * @return Returns Hash of Wallpaper Bitmap or 0
	 * @see #isWallpaperChanged(Bitmap, Context)
	 */
	public static int setWallpaperBackground(Activity activity) {
		View root = activity.getWindow().getDecorView();
		Drawable wallpaper = getWallpaperDrawable(activity.getApplicationContext());
		root.setBackground(wallpaper);
		
		if(wallpaper instanceof BitmapDrawable)
			return ((BitmapDrawable) wallpaper).getBitmap().hashCode();
		else
			return 0;
	}
	
	/**
	 * Get Wallpaper bitmap. Provides access to hidden getBitmap() method
	 * of {@link android.app.WallpaperManager}
	 * 
	 * @param context
	 * @return Returns Wallpaper Drawable
	 */
	public static Drawable getWallpaperDrawable(Context context) {
		BitmapDrawable bitmap = null;
		WallpaperManager walManager = WallpaperManager.getInstance(context);
		try {
			Method m = walManager.getClass().getDeclaredMethod("getBitmap", null);
			m.setAccessible(true);
			bitmap = new BitmapDrawable(context.getResources(), (Bitmap) m.invoke(walManager, null));
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		if(bitmap == null) {
			// Problem in accessing hidden Method "getBitmap"
			return walManager.getDrawable();
		}
		
		return bitmap;
	}
	
	/**
	 * Get Wallpaper Bitmap
	 * 
	 * @param context
	 * @return Wallpaper Bitmap
	 */
	public static Bitmap getWallpaperBitmap(Context context) {
		Drawable drawable = getWallpaperDrawable(context);
		if(drawable instanceof BitmapDrawable)
			return ((BitmapDrawable) drawable).getBitmap();
		else
			return new GraphicsInternal().getBitmap(drawable);
	}
	
	/**
	 * Checks whether Wallpaper has been changed.
	 * 
	 * @param prevWallpaper
	 * @param context
	 * @return Returns true if previous Bitmap is same as new System Wallpaper, 
	 * 		   otherwise false.
	 */
	public static boolean isWallpaperChanged(Bitmap prevWallpaper, Context context) {
		if(prevWallpaper == null || context == null)
			return false;
		
		Bitmap presentWallpaper = getWallpaperBitmap(context);
		
		if(presentWallpaper.hashCode() == prevWallpaper.hashCode())
			return true;
		else
			return false;
	}
	
	/**
	 * Checks whether Wallpaper has been changed.
	 * 
	 * @param hashCode Hashcode of previously set Wallpaper Bitmap.</br>
	 *        @see #setWallpaperBackground
	 * @param context
	 * @return Returns true if previous Bitmap is same as new System Wallpaper, 
	 * 		   otherwise false.
	 */
	public static boolean isWallpaperChanged(int hashCode, Context context) {
		Bitmap presentWallpaper = getWallpaperBitmap(context);
		
		if(presentWallpaper.hashCode() == hashCode)
			return true;
		else
			return false;
	}
}
