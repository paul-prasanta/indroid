package com.pras.call;

import com.indroid.TelephonyInternal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class HandleCall extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		System.out.println("Receiving Call....");
		//TelephonyInternal.answerRingingCall(context);
		TelephonyInternal.endCall(context);
	}
}
