/*
 * Copyright (C) 2013 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.indroid;

import java.lang.reflect.Method;

import android.content.Context;
import android.telephony.TelephonyManager;

/**
 * This Class provides access to hidden methods and variables of
 * {@link android.telephony.TelephonyManager}, <code>ITelephony.aidl</code> and <code>IPhoneSubInfo.aidl</code>.
 * <p>
 * This Class requires following permissions-<br>
 * - <code>android.permission.READ_PHONE_STATE</code><br>
 * - <code>android.permission.MODIFY_PHONE_STATE</code><br>
 * - <code>android.permission.CALL_PHONE</code><br>
 * 
 * @author Prasanta Paul
 */
public class TelephonyInternal {

	/**
	 * Get instance of <code>ITelephony.aidl</code>
	 * 
	 * @param context
	 * @return Returns object of Remote service which implements <code>ITelephony.aidl</code>
	 */
	public static Object getITelephony(Context context) {
		System.out.println("getITelephony...........");
		Object iTelephony = null;
		try {
			TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			Class cl = manager.getClass();
			System.out.println("Tele: "+ cl.getName());
			Method m = null;
			// In some Devices TelephonyManager has been Sub-classed. So check its Supper
			while(true) {
				try {
					m = cl.getDeclaredMethod("getITelephony");
					Method[] ms = cl.getDeclaredMethods();
					for(int i=0; i<ms.length; i++)
						System.out.print("-> "+ ms[i].getName());
				} catch (NoSuchMethodException e) {
					// Check its Super
					cl = cl.getSuperclass();
					e.printStackTrace();
					System.out.println("cl: "+ cl);
				}
				if(m != null || cl == null || cl == Object.class)
					break;
			}
			System.out.println("Method: "+ m);
			if(m == null)
				return null;
			
			System.out.println("Invoke....");
			m.setAccessible(true);
			iTelephony = m.invoke(manager);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("iTelephony"+ iTelephony);
		return iTelephony;
	}
	
	/**
	 * Get instance of <code>IPhoneSubInfo.aidl</code>
	 * 
	 * @param context
	 * @return Returns object of Remote service which implements <code>IPhoneSubInfo.aidl</code>
	 */
	public static Object getIPhoneSubInfo(Context context) {
		Object iPhoneSubInfo = null;
		try {
			TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			Class cl = manager.getClass();
			Method m = null;
			// In some Devices TelephonyManager has been Sub-classed. So check its Supper
			while(true) {
				try {
					m = cl.getClass().getMethod("getSubscriberInfo", null);
				} catch (NoSuchMethodException e) {
					// Check its Super
					cl = cl.getClass().getSuperclass();
				}
				if(m != null || cl == null)
					break;
			}
			
			if(m == null)
				return null;
			
			m.setAccessible(true);
			iPhoneSubInfo = m.invoke(manager, null);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return iPhoneSubInfo;
	}
	
	/**
	 * End incoming Call
	 * 
	 * @param context
	 * @return Returns <code>true</code> if operation is successful, otherwise <code>false</code>
	 */
	public static boolean endCall(Context context) {
		boolean isSuccess = false;
		Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return isSuccess;
		try {
			Method m = mITelephony.getClass().getMethod("endCall", null);
			m.setAccessible(true);
			isSuccess = (Boolean) m.invoke(mITelephony, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
	}
	
	/**
	 * Answer incoming Call
	 * 
	 * @param context
	 */
	public static void answerRingingCall(Context context) {
		Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return;
		try {
			Method m = mITelephony.getClass().getMethod("answerRingingCall", null);
			m.setAccessible(true);
			m.invoke(mITelephony, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Is Radio ON ?
	 * 
	 * @param context
	 * @return Returns <code>true</code> if operation Radio is ON, otherwise <code>false</code>
	 */
	public static boolean isRadioOn(Context context) {
		boolean isON = false;
		Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return isON;
		
		try {
			Method m = mITelephony.getClass().getMethod("isRadioOn", null);
			m.setAccessible(true);
			isON = (Boolean) m.invoke(mITelephony, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isON;
	}
	
	/**
	 * Enable/Disable Cell Radio
	 * 
	 * @param enable
	 * @param context
	 */
	public static void setRadio(boolean enable, Context context) {
		Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return;
		
		try {
			Method m = mITelephony.getClass().getMethod("setRadio", new Class[] {boolean.class});
			m.setAccessible(true);
			m.invoke(mITelephony, new Object[]{enable});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
    /**
     * Disallow mobile data connections.
     * 
     * @param context
     * @return Returns <code>true</code> if operation is successful, otherwise <code>false</code>
     */
    public static boolean disableDataConnectivity(Context context) {
    	boolean isDisabled = false;
    	Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return isDisabled;
    	try {
			Method m = mITelephony.getClass().getMethod("disableDataConnectivity", null);
			m.setAccessible(true);
			isDisabled = (Boolean) m.invoke(mITelephony, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return isDisabled;
    }

    /**
     * Report whether data connectivity is possible.
     * 
     * @param context
     * @return Returns <code>true</code> if Data Connectivity is possible, 
     *         otherwise <code>false</code>
     */
    public static boolean isDataConnectivityPossible(Context context) {
    	boolean isDataConnectivityPossible = false;
    	Object mITelephony = getITelephony(context);
		if(mITelephony == null)
			return isDataConnectivityPossible;
		try {
			Method m = mITelephony.getClass().getMethod("isRadioOn", null);
			m.setAccessible(true);
			isDataConnectivityPossible = (Boolean) m.invoke(mITelephony, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDataConnectivityPossible;
    }
    
    /**
     * Retrieves MSISDN Number.
     * 
     * @param context
     * @return Returns MSISDN number or <code>null</code>
     */
    public static String getMsisdn(Context context) {
    	String msisdn = null;
    	Object mIPhoneSubInfo = getIPhoneSubInfo(context);
    	if(mIPhoneSubInfo == null)
    		return msisdn;
    	
    	try {
			Method m = mIPhoneSubInfo.getClass().getMethod("getMsisdn", null);
			m.setAccessible(true);
			msisdn = (String) m.invoke(mIPhoneSubInfo, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msisdn;
    }
    
    /**
     * Returns the IMS private user identity (IMPI) that was loaded from the ISIM.
     * 
     * @param context
     * @return Returns IMPI, or <code>null</code> if not present or not loaded
     */
    public static String getIsimImpi(Context context) {
    	String IsimImpi = null;
    	Object mIPhoneSubInfo = getIPhoneSubInfo(context);
    	if(mIPhoneSubInfo == null)
    		return IsimImpi;
    	
    	try {
			Method m = mIPhoneSubInfo.getClass().getMethod("getIsimImpi", null);
			m.setAccessible(true);
			IsimImpi = (String) m.invoke(mIPhoneSubInfo, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return IsimImpi;
    }
    
    /**
     * Returns the IMS home network domain name that was loaded from the ISIM.
     * 
     * @param context
     * @return Returns IMS domain name, or <code>null</code> if not present or not loaded
     */
    public static String getIsimDomain(Context context) {
    	String IsimDomain = null;
    	Object mIPhoneSubInfo = getIPhoneSubInfo(context);
    	if(mIPhoneSubInfo == null)
    		return IsimDomain;
    	
    	try {
			Method m = mIPhoneSubInfo.getClass().getMethod("getIsimDomain", null);
			m.setAccessible(true);
			IsimDomain = (String) m.invoke(mIPhoneSubInfo, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return IsimDomain;
    }
    
    /**
     * Returns the IMS public user identities (IMPU) that were loaded from the ISIM.
     * 
     * @param context
     * @return  Returns an array of IMPU strings, with one IMPU per string, or <code>null</code> 
     * 			if not present or not loaded
     */
    public static String[] getIsimImpu(Context context) {
    	String[] IsimImpu = null;
    	Object mIPhoneSubInfo = getIPhoneSubInfo(context);
    	if(mIPhoneSubInfo == null)
    		return IsimImpu;
    	
    	try {
			Method m = mIPhoneSubInfo.getClass().getMethod("getIsimImpu", null);
			m.setAccessible(true);
			IsimImpu = (String[]) m.invoke(mIPhoneSubInfo, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return IsimImpu;
    }
}
